
All Hidden Units v0.8 (*.dats) - AoE, RoR

====================================================================================

Ingo van Thiel: "Great discovery, lots of new toys to play with."

Andrea Rosa: "Awesome job, scenario_t_c! You've earned your place in AoE history, and a very important place. "

Richard Ames: "Oh dear, I think they missed the whole point of this feature - templates are USELESS now."

LittleFreak: "This is truly awesome."

Dangrimm: How the heck did I miss this thread all that time?

====================================================================================

-How to Use This Utility (AoE)

1. Make a backup of C:\Program Files\Microsoft Games\Age of Empires\data\empires.dat
2. Extract data\empires.dat within the zip file into C:\Program Files\Microsoft Games\Age of Empires\
3. Run Age of Empires 
4. Go into the Scenario Editor
5. Click the Unit Tab, and select the player as GAIA
6. You will find that new units are avilable to GAIA player now!

Note: Some hidden units are available to normal players with Egyptian civilization instead of GAIA players. 

-How to Use This Utility (RoR)

1. Make a backup of C:\Program Files\Microsoft Games\Age of Empires\data2\empires.dat
2. Extract data2\empires.dat within the zip file into C:\Program Files\Microsoft Games\Age of Empires\
3. Run Age of Empires: Rise of Rome
4. Go into the Scenario Editor
5. Click the Unit Tab, and select the player as GAIA
6. You will find that new units are avilable to GAIA player now!

Note: Some hidden units are available to normal players with Egyptian civilization instead of GAIA players. 

Screenshots:

http://img.photobucket.com/albums/v124/scenario_tc/AoE0006.jpg
http://img.photobucket.com/albums/v124/scenario_tc/AoE0004.jpg

Future Update:
-All hidden units for all players
-A list of hidden units
